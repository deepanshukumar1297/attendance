package pojo;

public class Coordinator
{
	
	private String coordinator_teacherId;
	private String coordinator_sectionId;
	
	public String getCoordinator_teacherId() {
		return coordinator_teacherId;
	}
	public void setCoordinator_teacherId(String coordinator_teacherId) {
		this.coordinator_teacherId = coordinator_teacherId;
	}
	public String getCoordinator_sectionId() {
		return coordinator_sectionId;
	}
	public void setCoordinator_sectionId(String coordinator_sectionId) {
		this.coordinator_sectionId = coordinator_sectionId;
	}
	

	
}
