package pojo;

public class Student
{
	private String student_name;
	private String student_id;
	private String student_sectionId;
	
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getStudent_sectionId() {
		return student_sectionId;
	}
	public void setStudent_sectionId(String student_sectionId) {
		this.student_sectionId = student_sectionId;
	}


}
